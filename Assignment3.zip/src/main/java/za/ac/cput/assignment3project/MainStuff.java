/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.cput.assignment3project;

import java.io.*;
import java.time.LocalDate;
import java.util.*;
import java.util.Comparator;
import static java.util.Comparator.comparing;
import java.time.Period;
import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;
/**
 *
 * @author joshu
 */
public class MainStuff {
    private ObjectInputStream input;
    Stakeholder stakeholder;
    ArrayList<Stakeholder> SList = new ArrayList<Stakeholder>();
    ArrayList<Customer> clist = new ArrayList<>();
    ArrayList<Supplier> slist = new ArrayList<>();
    
    private LocalDate currentDate = LocalDate.now();
    private LocalDate custDate;
    private LocalDate custDate2;
    private Date thisDate = new Date();
    private SimpleDateFormat dateForm = new SimpleDateFormat("dd MMMM YYYY");
    
    private static ArrayList totRent = new ArrayList();
    private static ArrayList totNotRent = new ArrayList();
    
    private File custOut;
    private File suppOut;
    private FileWriter fw;
    private FileWriter fw2;
    private PrintWriter pw;
    private PrintWriter pw2;
    
    private boolean t = true;
    
    //open and close done
    public void openFile(){
        try{
            input = new ObjectInputStream( new FileInputStream( "C:\\Users\\joshu\\Dropbox\\My PC (LAPTOP-GL5QPPVH)\\Documents\\NetBeansProjects\\Assignment3\\stakeholder.ser" ) ); 
            System.out.println("*** ser file created and open ***");               
        }
        catch (IOException ioe){
            System.out.println("error opening ser file: " + ioe.getMessage());
            System.exit(1);
        }
    }
    public void closeFile(){
        try{
            input.close( ); 
            System.out.println("*** ser file closed ***");
        }
        catch (IOException ioe){            
            System.out.println("error closing ser file: " + ioe.getMessage());
            System.exit(1);
        }        
    }
    
    //read from stakeholder
    public void readFromFile(){
        try{
            while(true){
                stakeholder = (Stakeholder)input.readObject();
                System.out.println(stakeholder);
            }
        } catch(ClassNotFoundException | IOException e){
            System.out.println("Error reading from ser file");
        } finally{
            closeFile();
        }
    }
    //read from customer
    public void readCustomer(){
        try{
            while(true){
                stakeholder = (Stakeholder)input.readObject();
                if(stakeholder instanceof Customer){
                    clist.removeAll(clist);
                    clist.add((Customer)stakeholder);
                    Collections.sort(clist, custIdComparator);
                    for (int i = 0; i < clist.size(); i++) {
                        System.out.printf("%-10s\t%-10s\t%-10s\t%-15s\t%-10s\n", clist.get(i).getStHolderId(), clist.get(i).getFirstName(), clist.get(i).getSurName(), formatDate(),  findAgeCust());
                        findCustRent();
                        findCustNotRent();
                    }
                }
            }
        } catch(ClassNotFoundException | IOException e){
            //System.out.println("Error reading from ser file");
        } finally{
            closeFile();
        }
        
    }
    
    //
    public void readSupplier(){
        try{
            while(true){
                stakeholder = (Stakeholder)input.readObject();
                if(stakeholder instanceof Supplier){
                    slist.removeAll(slist);
                    slist.add((Supplier)stakeholder);
                    Collections.sort(slist, suppNameComparator);
                    for (int i = 0; i < slist.size(); i++) {
                        System.out.println(slist.get(i).toString());
                    }
                }
            }
        } catch(ClassNotFoundException | IOException e){
            //System.out.println("Error reading from ser file");
        } finally{
            closeFile();
        }
        
    }
    
    //sorting methods
    public static Comparator<Customer> custIdComparator = new Comparator<Customer>() {

	public int compare(Customer cust1, Customer cust2) {
	   String custId = cust1.getStHolderId();
	   String custId2 = cust2.getStHolderId();

	   return custId.compareTo(custId2);
    }};
   
    public static Comparator<Supplier> suppNameComparator = new Comparator<Supplier>() {

	public int compare(Supplier supp1, Supplier supp2) {
	   String suppId = supp1.getName();
	   String suppId2 = supp2.getName();

	   return suppId.compareTo(suppId2);
    }};
    
    public String testDateFormat(){
        String birth = null;
        for (int i = 0; i < clist.size(); i++) {
            custDate2 = LocalDate.parse(clist.get(i).getDateOfBirth());
            birth = dateForm.format(custDate2);
        }
        return birth;
    }
    
    private String formatDate()
    {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd MMMM yyyy", Locale.ENGLISH);
        
        for (int i = 0; i < clist.size(); i++) {
            custDate2 = LocalDate.parse(clist.get(i).getDateOfBirth());
        }
        
        return custDate2.format(formatter);
    }

    
    //finding the age
    public int findAgeCust(){
        int years = 0;
        for (int i = 0; i < clist.size(); i++) {
            custDate = LocalDate.parse(clist.get(i).getDateOfBirth());
            years = Period.between(custDate, currentDate).getYears();
            //System.out.println(years);
        }
        return years;
    }
    
    //finding customers who can rent
    public void findCustRent(){
        for (int i = 0; i < clist.size(); i++) {
            if(clist.get(i).getCanRent() == true){
                totRent.add(clist.get(i).getCanRent());
            }
        }
        //System.out.println(totRent.size());
    }
    
    public void findCustNotRent(){
        for (int i = 0; i < clist.size(); i++) {
            if(clist.get(i).getCanRent() == false){
                totNotRent.add(clist.get(i).getCanRent());
            }
        }
        //System.out.println(totNotRent.size());
    }
    
    public void closeOutputFilesCust(){
        try{
            fw.close();
            pw.close();
        } catch (IOException e){
        
        }
    }
    
    public void closeOutputFilesSupp(){
        try{
            fw2.close();
            pw2.close();
        }catch(IOException e){
        
        }
    }
    
    //writing the the text file
    public void writeToFileCust(){
        int sizecust = clist.size();
        try{
            custOut = new File("CustomerOutFile.txt");
            fw = new FileWriter(custOut);
            pw = new PrintWriter(fw);
            pw.println("-------------------------------------------Customer--------------------------------------------");
            pw.printf("%-10s\t%-10s\t%-10s\t%-15s\t%-10s","ID","Name","Surname","Date of Birth", "Age\n");
            pw.println("-----------------------------------------------------------------------------------------------");
            for (int i = 0; i < sizecust; i++) {
                pw.printf("%-10s\t%-15s\t%-10s\t%-15s\t%-10s\n", clist.get(i).getStHolderId(), clist.get(i).getFirstName(), clist.get(i).getSurName(), formatDate(),  findAgeCust());
                findCustRent();
                findCustNotRent();
            }
            
            pw.println("The total amount of customers who can rent are : "+totRent.size());
            pw.println("The total amount of customers who cannot rent are: "+totNotRent.size());
            pw.println(" ");
            closeOutputFilesCust();
            
        } catch (Exception e){
            System.out.println("Created Customer Output File");
        }
    }
    
    public void writeToFileSupp(){
        int sizesupp = slist.size();
        try{
            suppOut = new File("SupplierOutFile.txt");
            fw2 = new FileWriter(suppOut);
            pw2 = new PrintWriter(fw2);
            pw2.println("------------------------------------------Supplier--------------------------------------------");
            pw2.printf("%-10s\t%-10s\t%-10s\t%-10s","ID","Name","Product Type","Description\n");
            pw2.println("----------------------------------------------------------------------------------------------");
            for (int i = 0; i < sizesupp; i++) {
                while(sizesupp < 6){
                    pw2.println(slist.get(i).toString());
                }
            }
            closeOutputFilesSupp();
        } catch(Exception e){
            System.out.println("Created Supplier Output File");
        }
    }
     
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        MainStuff ms = new MainStuff();
        
        ms.openFile();
        System.out.println("Reading in customer objects...");
        System.out.println("------------------------------Customer--------------------------------");
        System.out.println("ID\t\tName\t\tSurname\t\tDate of Birth\t\tAge");
        System.out.println("----------------------------------------------------------------------");
        ms.readCustomer();
        System.out.println("The total amount of customers who can rent are : "+totRent.size());
        System.out.println("The total amount of customers who cannot rent are: "+totNotRent.size());
        
        System.out.println(" ");
        
        ms.openFile();
        System.out.println("Reading in supplier objects...");
        System.out.println("------------------------------Supplier--------------------------------");
        System.out.println("ID\tName\t\t\tProduct Type\tDescription");
        System.out.println("----------------------------------------------------------------------");
        ms.readSupplier();
        
        ms.writeToFileCust();
        System.out.println("\nCreated Customer output file");
        ms.writeToFileSupp();
        System.out.println("\nCreated Supplier output file");
    }
    
}
